function setup() {
  createCanvas(800, 800); 
}

function draw() {
  background(100); 
  textStyle(BOLDITALIC);
  textSize(32);
   text('Harrisburg University', 260, 40);
  
  textSize(14);
  text('I am an interactive media student learning how to design video games.',0, 100);
  text('I know how to use game engines like Unreal and Unity.', 0 ,120);
  text('I am learning how to use JavaScript. ',0 , 140);
  
  
  
}
